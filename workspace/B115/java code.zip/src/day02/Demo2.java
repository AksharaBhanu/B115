package day02;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.SearchContext;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chromium.ChromiumDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.safari.SafariDriver;

public class Demo2 {
//to get FQCN
	public static void main(String[] args) {
		ChromeDriver a;
		EdgeDriver b;
		FirefoxDriver c;
		InternetExplorerDriver d;
		SafariDriver e;
		
		ChromiumDriver f;
		RemoteWebDriver g;
		
		WebDriver h;
		SearchContext i;
		JavascriptExecutor j;
		TakesScreenshot k;
	}

}
